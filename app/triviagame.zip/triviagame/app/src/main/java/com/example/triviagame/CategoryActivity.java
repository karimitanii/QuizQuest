package com.example.triviagame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CategoryActivity extends AppCompatActivity {

    private TextView usernameDisplay;
    private Button scienceButton, geographyButton, historyButton, footballButton, technologyButton, entertainmentButton, settingsButton;
    private String userId; // Store the user ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_category);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //  UI elements
        usernameDisplay = findViewById(R.id.usernameDisplay);
        scienceButton = findViewById(R.id.scienceButton);
        geographyButton = findViewById(R.id.geographyButton);
        historyButton = findViewById(R.id.historyButton);
        footballButton = findViewById(R.id.footballButton);
        technologyButton = findViewById(R.id.technologyButton);
        entertainmentButton = findViewById(R.id.entertainmentButton);
        settingsButton = findViewById(R.id.settingsButton);

        // Get the username and user_id passed from LoginActivity
        String username = getIntent().getStringExtra("username");
        userId = getIntent().getStringExtra("user_id");

        updateUsername(username);

        setupButtonListeners();

        setupSettingsButton();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Handle new data when the activity is relaunched
        String updatedUsername = intent.getStringExtra("username");
        if (updatedUsername != null) {
            updateUsername(updatedUsername);
        }
    }

    private void updateUsername(String username) {
        if (username != null) {
            usernameDisplay.setText("" + username + "!");
        } else {
            usernameDisplay.setText("Guest");
        }
    }

    private void setupButtonListeners() {
        scienceButton.setOnClickListener(v -> startQuiz("Science"));
        geographyButton.setOnClickListener(v -> startQuiz("Geography"));
        historyButton.setOnClickListener(v -> startQuiz("History"));
        footballButton.setOnClickListener(v -> startQuiz("Football"));
        technologyButton.setOnClickListener(v -> startQuiz("Technology"));
        entertainmentButton.setOnClickListener(v -> startQuiz("Entertainment"));
    }

    private void startQuiz(String category) {
        // Pass the selected category to QuizActivity
         Intent intent = new Intent(CategoryActivity.this, QuizActivity.class);
         intent.putExtra("category", category);
        intent.putExtra("user_id", userId);
        intent.putExtra("username", usernameDisplay.getText().toString()); // Pass the current username
         startActivity(intent);
    }

    private void setupSettingsButton() {
        settingsButton.setOnClickListener(v -> {
            // Navigate to SettingsActivity and pass user_id
            Intent intent = new Intent(CategoryActivity.this, SettingsActivity.class);
            intent.putExtra("user_id", userId); // Pass the user ID
            intent.putExtra("username", usernameDisplay.getText().toString()); // Pass the current username
            startActivity(intent);
        });
    }
}
