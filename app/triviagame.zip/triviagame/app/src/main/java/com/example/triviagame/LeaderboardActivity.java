package com.example.triviagame;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LeaderboardActivity extends AppCompatActivity {

    private Spinner categorySpinner;
    private TableLayout leaderboardTable;
    private String selectedCategory = "All";
    private Button backButton;
    private int correctAnswers = 0;
    private int score;


    private String userId, username, category;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_leaderboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        categorySpinner = findViewById(R.id.categorySpinner);
        leaderboardTable = findViewById(R.id.leaderboardTable);
        backButton = findViewById(R.id.backButton);

        userId = getIntent().getStringExtra("user_id");
        username = getIntent().getStringExtra("username");
        score = getIntent().getIntExtra("score", 0); // Use getIntExtra with a default value



        // Set up spinner
        setupCategorySpinner();

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(LeaderboardActivity.this, ShowResultsActivity.class);
            intent.putExtra("user_id", userId);
            intent.putExtra("username", username);
            intent.putExtra("category", category);
            intent.putExtra("score", score); // Pass score correctly
            startActivity(intent);
            finish(); // Close this activity
        });


        // get and display the leaderboard
        fetchLeaderboard();
    }

    private void setupCategorySpinner() {
        // Define categories
        String[] categories = {"All", "Science", "Geography", "History", "Football", "Technology", "Entertainment"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = categories[position];
                fetchLeaderboard();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void fetchLeaderboard() {
        leaderboardTable.removeAllViews();
        // get req volley

        String url = "http://192.168.100.58/Web-GT/triviagame/leaderboard.php";
        if (!selectedCategory.equals("All")) {
            url += "?category=" + selectedCategory;
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        if (response.getBoolean("success")) {
                            JSONArray leaderboardArray = response.getJSONArray("leaderboard");
                            for (int i = 0; i < leaderboardArray.length(); i++) {
                                JSONObject row = leaderboardArray.getJSONObject(i);
                                addRowToTable(
                                        row.getString("username"),
                                        row.getString("category"),
                                        row.getInt("score")
                                );
                            }
                        } else {
                            Toast.makeText(this, "No leaderboard data available.", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing response.", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show());

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void addRowToTable(String username, String category, int score) {
        TableRow row = new TableRow(this);

        TextView usernameText = new TextView(this);
        usernameText.setText(username);
        usernameText.setPadding(8, 8, 8, 8);

        TextView categoryText = new TextView(this);
        categoryText.setText(category);
        categoryText.setPadding(8, 8, 8, 8);

        TextView scoreText = new TextView(this);
        scoreText.setText(String.valueOf(score));
        scoreText.setPadding(8, 8, 8, 8);

        row.addView(usernameText);
        row.addView(categoryText);
        row.addView(scoreText);

        leaderboardTable.addView(row);
    }
}
