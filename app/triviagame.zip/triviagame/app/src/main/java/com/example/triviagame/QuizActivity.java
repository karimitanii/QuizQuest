package com.example.triviagame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuizActivity extends AppCompatActivity {

    private TextView usernameDisplay, questionDisplay;
    private ProgressBar progressBar;
    private RadioGroup optionsGroup;
    private RadioButton optionA, optionB, optionC;
    private Button submitButton;

    private String userId, username, category;
    private List<Question> questionsList = new ArrayList<>();
    private int currentQuestionIndex = 0;
    private int correctAnswers = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        usernameDisplay = findViewById(R.id.usernameDisplay);
        questionDisplay = findViewById(R.id.questionDisplay);
        progressBar = findViewById(R.id.progressBar);
        optionsGroup = findViewById(R.id.optionsGroup);
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        submitButton = findViewById(R.id.submitButton);

        progressBar.setMax(100); // max val for progress bar
        progressBar.setProgress(0); // Initialize progress bar to 0

        // Get data from intent
        username = getIntent().getStringExtra("username");
        userId = getIntent().getStringExtra("user_id");
        category = getIntent().getStringExtra("category");

        String cleanUsername = username.replace("Welcome back ", "").replace("!", "");
        usernameDisplay.setText(cleanUsername);
        fetchQuestions();

        setupSubmitButton();
    }

    // post req volley

    private void fetchQuestions() {
        String url = "http://192.168.100.58/Web-GT/triviagame/questions.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            JSONArray questionsArray = jsonObject.getJSONArray("questions");
                            for (int i = 0; i < questionsArray.length(); i++) {
                                JSONObject questionObj = questionsArray.getJSONObject(i);
                                Question question = new Question(
                                        questionObj.getString("question_text"),
                                        questionObj.getString("option_a"),
                                        questionObj.getString("option_b"),
                                        questionObj.getString("option_c"),
                                        questionObj.getString("correct_option")
                                );
                                questionsList.add(question);
                            }
                            // Display the questions
                            displayQuestion();
                        } else {
                            Toast.makeText(this, "No questions available", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("category", category);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void displayQuestion() {
        if (currentQuestionIndex < questionsList.size()) {
            Question currentQuestion = questionsList.get(currentQuestionIndex);
            questionDisplay.setText(currentQuestion.getQuestionText());
            optionA.setText(currentQuestion.getOptionA());
            optionB.setText(currentQuestion.getOptionB());
            optionC.setText(currentQuestion.getOptionC());
            optionsGroup.clearCheck(); // Reset options
        } else {
            // if all questions answered, go to ShowResultsActivity
            navigateToResults();
        }
    }

    private void setupSubmitButton() {
        submitButton.setOnClickListener(v -> validateAnswer());
    }

    private void validateAnswer() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
            return;
        }

        // Mapping the selected RadioButton to its corresponding option (A, B, or C)
        String selectedAnswer = null;
        if (selectedId == optionA.getId()) {
            selectedAnswer = "A";
        } else if (selectedId == optionB.getId()) {
            selectedAnswer = "B";
        } else if (selectedId == optionC.getId()) {
            selectedAnswer = "C";
        }

        // Ensure the selected answer is not empty
        if (selectedAnswer == null) {
            Toast.makeText(this, "Invalid option selected", Toast.LENGTH_SHORT).show();
            return;
        }

        // Compare with the correct answer
        String correctAnswer = questionsList.get(currentQuestionIndex).getCorrectOption();
        if (selectedAnswer.equals(correctAnswer)) {
            correctAnswers++;
            progressBar.incrementProgressBy(10); // Increment progress bar by 10
        }

        currentQuestionIndex++;
        if (currentQuestionIndex < questionsList.size()) {
            displayQuestion(); // Load the next question
        } else {
            navigateToResults(); // When Quiz is complete
        }
    }








    private void navigateToResults() {
        Intent intent = new Intent(QuizActivity.this, ShowResultsActivity.class);
        intent.putExtra("user_id", userId);
        intent.putExtra("username", username); // Pass the username
        intent.putExtra("category", category);
        intent.putExtra("score", correctAnswers); // Pass the score
        startActivity(intent);
        finish();

    }



    private static class Question {
        private String questionText, optionA, optionB, optionC, correctOption;

        public Question(String questionText, String optionA, String optionB, String optionC, String correctOption) {
            this.questionText = questionText;
            this.optionA = optionA;
            this.optionB = optionB;
            this.optionC = optionC;
            this.correctOption = correctOption;
        }

        public String getQuestionText() {
            return questionText;
        }

        public String getOptionA() {
            return optionA;
        }

        public String getOptionB() {
            return optionB;
        }

        public String getOptionC() {
            return optionC;
        }

        public String getCorrectOption() {
            return correctOption;
        }
    }
}
