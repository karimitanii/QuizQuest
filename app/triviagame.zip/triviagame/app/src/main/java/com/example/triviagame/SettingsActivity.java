package com.example.triviagame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SettingsActivity extends AppCompatActivity {

    private Button changeUsernameButton, changePasswordButton, logoutButton , backButton;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userId = getIntent().getStringExtra("user_id");

        changeUsernameButton = findViewById(R.id.changeUsernameButton);
        changePasswordButton = findViewById(R.id.changePasswordButton);
        logoutButton = findViewById(R.id.logoutButton);
        backButton = findViewById(R.id.backButton); // Initialize the back button


        setupButtonListeners();
    }

    private void setupButtonListeners() {
        changeUsernameButton.setOnClickListener(v -> {
            // go to ChangeUsernameActivity and pass user_id
            Intent intent = new Intent(SettingsActivity.this, ChangeUsernameActivity.class);
            intent.putExtra("user_id", userId);
            startActivity(intent);
        });

        changePasswordButton.setOnClickListener(v -> {
            // go to ChangePasswordActivity and pass user_id
            Intent intent = new Intent(SettingsActivity.this, ChangePasswordActivity.class);
            intent.putExtra("user_id", userId);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> {
            // Log out and go to MainActivity
            Intent logoutIntent = new Intent(SettingsActivity.this, MainActivity.class);
            logoutIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(logoutIntent);
            finish(); // Close current activity
        });

        backButton.setOnClickListener((v -> {
            Intent intent = new Intent(SettingsActivity.this, CategoryActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            intent.putExtra("user_id", userId);

            finish();
        }));
    }
}
