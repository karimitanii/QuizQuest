package com.example.triviagame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ShowResultsActivity extends AppCompatActivity {

    private TextView resultsDisplay;
    private Button playAgainButton, leaderboardButton;
    private String userId, username, category;
    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_show_results);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        resultsDisplay = findViewById(R.id.resultsDisplay);
        playAgainButton = findViewById(R.id.playAgainButton);
        leaderboardButton = findViewById(R.id.leaderboardButton);

        userId = getIntent().getStringExtra("user_id");
        username = getIntent().getStringExtra("username");
        category = getIntent().getStringExtra("category");
        score = getIntent().getIntExtra("score", 0);

        // Displaying results
        resultsDisplay.setText("You scored " + score + "/10 correct!");

        // Submit score to backend
        submitScore();

        playAgainButton.setOnClickListener(v -> {
            Intent intent = new Intent(ShowResultsActivity.this, CategoryActivity.class);
            intent.putExtra("user_id", userId);
            intent.putExtra("username", username); // Pass the username
            startActivity(intent);
            finish(); // Close this activity
        });


        // Set up Leaderboard button
        leaderboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(ShowResultsActivity.this, LeaderboardActivity.class);
            intent.putExtra("user_id", userId);
            intent.putExtra("username", username);
            intent.putExtra("score", score);
            intent.putExtra("category", category); // Include category


            startActivity(intent);
        });
    }

    // post req volley

    private void submitScore() {
        String url = "http://192.168.100.58/Web-GT/triviagame/scores.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            Toast.makeText(this, "Score submitted successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", userId);
                params.put("category", category);
                params.put("score", String.valueOf(score));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
